const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const publicFolder = path.join(__dirname, "public");

app.use("/vendor/bootstrap", express.static(path.join(__dirname, "node_modules/bootstrap/dist")));
app.use(express.static(publicFolder));
// Todas as telas usam o mesmo app.js, como na página inicial da P1.
app.get("*", (req, res) => res.sendFile(path.join(publicFolder, "index.html")));
app.listen(PORT, () => console.log(`ONZE STORE: http://localhost:${PORT}`));
