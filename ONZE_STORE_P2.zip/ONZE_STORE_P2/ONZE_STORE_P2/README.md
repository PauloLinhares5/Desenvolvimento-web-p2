# ONZE STORE - P2 de Desenvolvimento Web

Projeto da P1 integrado com a API Java/Spring Boot fornecida pelo professor Norton Glaser.

## Como executar

1. Abra o backend `lojinha` na pasta que contém `pom.xml`.
2. Inicie com `.\mvnw.cmd spring-boot:run` no PowerShell.
3. Confira `http://localhost:8081/api/produtos`.
4. Abra a pasta deste projeto no VS Code e execute `npm install`.
5. Execute `npm run seed` uma vez para cadastrar as 12 camisetas no banco.
6. Execute `npm start` e abra `http://localhost:3000`.

Mantenha os dois terminais abertos durante a apresentação.

## O que foi integrado

- **Produtos:** consulta e busca pelo backend; cadastro inicial das camisetas pelo endpoint POST. O arquivo `public/js/api.js` contém também os métodos de alteração e exclusão.
- **Clientes:** cadastro, login, consulta, atualização e exclusão pela API.
- **Pedidos:** cadastro, consulta, alteração da observação e exclusão pela API.
- **Cesta:** continua no navegador, como na P1. A API recebida não tem rota documentada para itens do pedido.

## Arquivos principais

- `public/js/catalogo.js`: nomes, imagens e descrições das camisetas da P1.
- `public/js/app.js`: telas e funções do site.
- `public/js/api.js`: requisições ao backend (GET, POST, PUT e DELETE).
- `scripts/cadastrar-produtos.js`: inclusão dos produtos no banco, sem duplicar nomes.
- `server.js`: inicializa o frontend na porta 3000.

## Observações

- O backend fornecido pelo professor deve estar na porta `8081`.
- Os números de pedidos são gerados pelo banco de dados, não pelo JavaScript.
- A cesta e a relação de itens exibida em "Meus pedidos" são armazenadas no navegador. O backend recebido registra o pedido, mas o relacionamento com `ItemPedido` está comentado em `Pedido.java`.
- O código Java original do professor não está incluído neste ZIP. Execute o projeto `lojinha` separadamente.
- A aplicação é um trabalho de sala e não deve ser publicada como serviço de vendas reais sem implementar autenticação segura e pagamento apropriado.
