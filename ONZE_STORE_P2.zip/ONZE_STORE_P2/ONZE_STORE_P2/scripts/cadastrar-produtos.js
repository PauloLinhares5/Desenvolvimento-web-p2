// Cadastra os produtos da P1 no banco de dados da lojinha.
const catalogo = require("../public/js/catalogo.js");
const API_URL = process.env.API_URL || "http://127.0.0.1:8081";

async function executar() {
  const resposta = await fetch(`${API_URL}/api/produtos`);
  if (!resposta.ok) throw new Error(`Falha ao consultar produtos: ${resposta.status}`);
  const existentes = await resposta.json();
  if (!Array.isArray(existentes)) throw new Error("API não retornou uma lista.");
  let cadastrados = 0;
  for (const produto of catalogo) {
    if (existentes.some((item) => String(item.nome || item.descricao || item.descritivo || "").toLowerCase() === produto.name.toLowerCase())) {
      console.log(`Já existe: ${produto.name}`);
      continue;
    }
    const salvo = await fetch(`${API_URL}/api/produto`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        nome: produto.name,
        descritivo: produto.description,
        valor: produto.price,
        valorPromo: 0,
        quantidade: 20,
        destaque: 1
      })
    });
    const mensagem = await salvo.text();
    if (!salvo.ok) throw new Error(`Erro em ${produto.name}: ${mensagem}`);
    console.log(`${produto.name}: ${mensagem}`);
    cadastrados++;
  }
  console.log(`Finalizado. ${cadastrados} produto(s) cadastrado(s).`);
}
executar().catch((erro) => { console.error(erro.message); process.exitCode = 1; });
