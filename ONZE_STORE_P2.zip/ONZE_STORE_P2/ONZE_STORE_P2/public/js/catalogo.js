const catalogoP1 = [
  {
    id: 1,
    name: "Camisa Flamengo I",
    team: "Flamengo",
    category: "Atual",
    price: 349.90,
    image: "/img/flamengo.jpg",
    description: "Modelo nas cores tradicionais do Flamengo."
  },
  {
    id: 2,
    name: "Camisa Flamengo II",
    team: "Flamengo",
    category: "Atual",
    price: 329.90,
    image: "/img/flamengo2.jpg",
    description: "Modelo alternativo do Flamengo."
  },
  {
    id: 3,
    name: "Camisa Retrô Flamengo",
    team: "Flamengo",
    category: "Retrô",
    price: 299.90,
    image: "/img/flamengo-retro.jpg",
    description: "Modelo retrô do Flamengo."
  },
  {
    id: 4,
    name: "Camisa Palmeiras I",
    team: "Palmeiras",
    category: "Atual",
    price: 349.90,
    image: "/img/palmeiras.jpg",
    description: "Modelo nas cores tradicionais do Palmeiras."
  },
  {
    id: 5,
    name: "Camisa Palmeiras II",
    team: "Palmeiras",
    category: "Atual",
    price: 329.90,
    image: "/img/palmeiras2.jpg",
    description: "Modelo alternativo do Palmeiras."
  },
  {
    id: 6,
    name: "Camisa Retrô Palmeiras",
    team: "Palmeiras",
    category: "Retrô",
    price: 299.90,
    image: "/img/palmeiras-retro.jpg",
    description: "Modelo retrô do Palmeiras."
  },
  {
    id: 7,
    name: "Camisa São Paulo I",
    team: "São Paulo",
    category: "Atual",
    price: 349.90,
    image: "/img/saopaulo.jpg",
    description: "Modelo nas cores do São Paulo."
  },
  {
    id: 8,
    name: "Camisa São Paulo II",
    team: "São Paulo",
    category: "Atual",
    price: 329.90,
    image: "/img/saopaulo2.jpg",
    description: "Modelo alternativo do São Paulo."
  },
  {
    id: 9,
    name: "Camisa Retrô São Paulo",
    team: "São Paulo",
    category: "Retrô",
    price: 299.90,
    image: "/img/saopaulo-retro.jpg",
    description: "Modelo retrô do São Paulo."
  },
  {
    id: 10,
    name: "Camisa Corinthians I",
    team: "Corinthians",
    category: "Atual",
    price: 349.90,
    image: "/img/corinthians.jpg",
    description: "Modelo em preto e branco."
  },
  {
    id: 11,
    name: "Camisa Corinthians II",
    team: "Corinthians",
    category: "Atual",
    price: 329.90,
    image: "/img/corinthians2.jpg",
    description: "Modelo alternativo do Corinthians."
  },
  {
    id: 12,
    name: "Camisa Retrô Corinthians",
    team: "Corinthians",
    category: "Retrô",
    price: 299.90,
    image: "/img/corinthians-retro.jpg",
    description: "Modelo retrô do Corinthians."
  }
];

if (typeof module !== "undefined") module.exports = catalogoP1;
