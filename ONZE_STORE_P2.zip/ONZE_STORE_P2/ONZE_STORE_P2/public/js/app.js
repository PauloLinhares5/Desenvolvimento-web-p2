let products = [];
let productLoadError = null;

function normalizar(texto) {
  return String(texto || "").trim().toLowerCase();
}

function adaptarProduto(item) {
  const nome = String(item.nome || item.descricao || item.descritivo || "Produto sem nome");
  const referencia = catalogoP1.find((produto) => normalizar(produto.name) === normalizar(nome));
  return {
    id: Number(item.codigo),
    name: nome,
    team: referencia?.team || "Outros",
    category: referencia?.category || "Produto",
    price: Number(item.valor || 0),
    image: referencia?.image || "/img/logo.png",
    description: referencia?.description || item.descritivo || nome
  };
}

async function carregarProdutos() {
  try {
    const resposta = await LojaAPI.produto.listar();
    if (!Array.isArray(resposta)) throw new Error("A API não devolveu uma lista de produtos.");
    products = resposta.filter((item) => item && Number.isFinite(Number(item.codigo))).map(adaptarProduto);
    productLoadError = null;
  } catch (erro) {
    products = [];
    productLoadError = erro.message;
  }
}

function mostrarAviso(formulario, mensagem, erro = true) {
  let aviso = formulario.querySelector(".api-feedback");
  if (!aviso) {
    aviso = document.createElement("div");
    aviso.className = "api-feedback alert mt-3";
    aviso.setAttribute("role", "alert");
    formulario.appendChild(aviso);
  }
  aviso.classList.toggle("alert-danger", erro);
  aviso.classList.toggle("alert-success", !erro);
  aviso.textContent = mensagem;
}

function clienteAtual() {
  return readStorage("onzeStoreCustomer", null);
}

const app = document.querySelector("#app");

function formatPrice(value) {
  return Number(value).toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL"
  });
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => {
    const map = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#039;"
    };

    return map[character];
  });
}

function readStorage(key, fallback) {
  try {
    const value = localStorage.getItem(key);
    return value ? JSON.parse(value) : fallback;
  } catch {
    return fallback;
  }
}

function saveStorage(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

function getCart() {
  return readStorage("onzeStoreCart", []);
}

function saveCart(cart) {
  saveStorage("onzeStoreCart", cart);
  updateCartCount();
}

function updateCartCount() {
  const count = getCart().reduce(
    (total, item) => total + Number(item.quantity || 0),
    0
  );

  document.querySelectorAll("[data-cart-count]").forEach((element) => {
    element.textContent = String(count);
  });
}

function headerTemplate() {
  const currentPath = window.location.pathname.replace(/\/$/, "") || "/";

  const links = [
    { label: "Vitrine", href: "/" },
    { label: "Buscar", href: "/busca" },
    { label: "Cesta", href: "/cesta" },
    { label: "Minha conta", href: "/conta" },
    { label: "Pedidos", href: "/pedidos" },
    { label: "Entrar", href: "/login" }
  ];

  return `
    <header class="store-header">
      <nav class="navbar navbar-expand-lg navbar-dark container-store">
        <a class="store-brand navbar-brand" href="/">
          <img
            class="store-logo"
            src="/img/logo.png"
            alt="Logo ONZE STORE"
            onerror="this.style.display='none'">
          <span>ONZE STORE</span>
        </a>

        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#storeNavigation"
          aria-controls="storeNavigation"
          aria-expanded="false"
          aria-label="Abrir menu">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="storeNavigation">
          <div class="navbar-nav ms-auto store-nav">
            ${links.map((link) => {
              const active = currentPath === link.href ? "active" : "";
              const label = link.href === "/cesta"
                ? `${link.label} <span class="cart-counter" data-cart-count>0</span>`
                : link.label;

              return `
                <a class="nav-link ${active}" href="${link.href}">
                  ${label}
                </a>
              `;
            }).join("")}
          </div>
        </div>
      </nav>
    </header>
  `;
}

function footerTemplate() {
  return `
    <footer class="site-footer">
      <div class="container-store">
        <img
          class="footer-logo"
          src="/img/logo.png"
          alt="Logo ONZE STORE"
          onerror="this.style.display='none'">
        <p>ONZE STORE | Camisetas de futebol</p>
        <small>Encontre a camisa do seu time</small>
      </div>
    </footer>
  `;
}

function productCard(product) {
  const categoryClass = product.category === "Retrô" ? "retro" : "";

  return `
    <article class="product-card">
      <div class="product-image-wrap">
        <img
          class="product-image"
          src="${product.image}"
          alt="${escapeHtml(product.name)}"
          onerror="this.style.display='none'; this.nextElementSibling.hidden=false">
        <div class="image-fallback" hidden>
          Imagem do produto<br>${escapeHtml(product.team)}
        </div>
      </div>

      <div class="product-content">
        <div class="product-tags">
          <span class="product-tag ${categoryClass}">
            ${escapeHtml(product.category)}
          </span>
          <span class="product-tag">${escapeHtml(product.team)}</span>
        </div>

        <h3>${escapeHtml(product.name)}</h3>
        <p class="product-price">${formatPrice(product.price)}</p>

        <div class="mt-auto">
          <a class="btn btn-store w-100" href="/detalhe?id=${product.id}">
            Ver detalhes
          </a>
        </div>
      </div>
    </article>
  `;
}

function renderProductGrid(list) {
  if (productLoadError) {
    return `<div class="alert alert-danger">Não foi possível carregar os produtos. ${escapeHtml(productLoadError)}</div>`;
  }
  if (list.length === 0) {
    return `
      <div class="empty-state">
        <h2>Nenhum produto encontrado</h2>
        <p>Se o banco estiver vazio, execute o cadastro inicial dos produtos (veja o README).</p>
      </div>
    `;
  }

  return list.map(productCard).join("");
}

function pageHome() {
  document.title = "ONZE STORE | Vitrine";

  return `
    <section class="hero">
      <div class="container-store hero-content">
        <p class="hero-kicker">Futebol brasileiro</p>
        <h1>Vista a camisa do seu time.</h1>
        <p>
          Camisetas atuais e retrô dos principais clubes brasileiros.
          Encontre seu próximo manto.
        </p>
        <a class="btn btn-store btn-lg" href="/busca">
          Explorar camisetas
        </a>
      </div>
    </section>

    <section class="container-store store-section">
      <div class="section-title-row">
        <div>
          <h2>Camisetas em destaque</h2>
          <p class="section-subtitle">
            Escolha seu time e encontre seu próximo manto.
          </p>
        </div>

        <a class="btn btn-store-outline" href="/busca">Ver todos</a>
      </div>

      <div class="product-grid">
        ${renderProductGrid(products)}
      </div>
    </section>
  `;
}

function pageSearch() {
  document.title = "ONZE STORE | Buscar";

  return `
    <section class="page-hero">
      <h1>Buscar camisetas</h1>
      <p>Pesquise pelo time, nome do modelo ou categoria.</p>
    </section>

    <section class="container-store store-section">
      <form id="search-form" class="search-box">
        <input
          id="search-input"
          class="form-control"
          type="search"
          placeholder="Exemplo: Flamengo, Corinthians ou Retrô"
          aria-label="Buscar produtos">
        <button class="btn btn-store" type="submit">Buscar</button>
      </form>

      <p id="search-count" class="text-secondary"></p>
      <div id="search-results" class="product-grid"></div>
    </section>
  `;
}

function pageDetail() {
  document.title = "ONZE STORE | Detalhe do produto";

  const params = new URLSearchParams(window.location.search);
  const id = Number(params.get("id")) || 1;
  const product = products.find((item) => item.id === id);

  if (!product) {
    return `
      <section class="container-store store-section">
        <div class="alert alert-warning">
          Produto não encontrado.
          <a href="/busca">Voltar para a busca</a>
        </div>
      </section>
    `;
  }

  const categoryClass = product.category === "Retrô" ? "retro" : "";

  return `
    <section class="container-store store-section">
      <p><a href="/busca">← Voltar para a busca</a></p>

      <div class="detail-grid">
        <div class="product-image-wrap rounded-4">
          <img
            class="detail-product-image"
            src="${product.image}"
            alt="${escapeHtml(product.name)}"
            onerror="this.style.display='none'; this.nextElementSibling.hidden=false">
          <div class="image-fallback" hidden>
            Imagem do produto<br>${escapeHtml(product.team)}
          </div>
        </div>

        <div>
          <div class="product-tags">
            <span class="product-tag">${escapeHtml(product.team)}</span>
            <span class="product-tag ${categoryClass}">
              ${escapeHtml(product.category)}
            </span>
          </div>

          <h1 class="mt-3 fw-bold">${escapeHtml(product.name)}</h1>
          <p class="product-price fs-3">${formatPrice(product.price)}</p>
          <p class="detail-description">${escapeHtml(product.description)}</p>

          <label for="product-size" class="form-label fw-bold">Tamanho</label>
          <select id="product-size" class="form-select mb-3">
            <option value="P">P</option>
            <option value="M" selected>M</option>
            <option value="G">G</option>
            <option value="GG">GG</option>
          </select>

          <button
            class="btn btn-store btn-lg w-100"
            type="button"
            data-add-to-cart="${product.id}">
            Adicionar à cesta
          </button>


        </div>
      </div>
    </section>
  `;
}

function pageCart() {
  document.title = "ONZE STORE | Cesta";

  return `
    <section class="container-store store-section">
      <h1 class="fw-bold mb-4">Minha cesta</h1>

      <div class="content-card p-3 p-md-4">
        <div id="cart-content"></div>

        <div class="cart-total">
          <strong>Total</strong>
          <strong id="cart-total" class="product-price">R$ 0,00</strong>
        </div>



        <button id="checkout-button" class="btn btn-store mt-2">
          Finalizar pedido
        </button>
      </div>
    </section>
  `;
}

function pageLogin() {
  document.title = "ONZE STORE | Entrar";

  return `
    <section class="container-store">
      <div class="form-card">
        <h1>Entrar na conta</h1>

        <form id="login-form">
          <div class="mb-3">
            <label for="login-email" class="form-label">E-mail</label>
            <input
              id="login-email"
              class="form-control"
              type="email"
              required>
          </div>

          <div class="mb-3">
            <label for="login-password" class="form-label">Senha</label>
            <input
              id="login-password"
              class="form-control"
              type="password"
              minlength="6"
              required>
          </div>

          <button class="btn btn-store w-100" type="submit">Entrar</button>
        </form>



        <p><a href="/cadastro">Criar cadastro</a></p>
      </div>
    </section>
  `;
}

function pageRegister() {
  document.title = "ONZE STORE | Cadastro";

  return `
    <section class="container-store">
      <div class="form-card">
        <h1>Criar cadastro</h1>

        <form id="register-form">
          <div class="mb-3">
            <label for="register-name" class="form-label">Nome completo</label>
            <input
              id="register-name"
              class="form-control"
              type="text"
              minlength="2"
              required>
          </div>

          <div class="mb-3">
            <label for="register-email" class="form-label">E-mail</label>
            <input
              id="register-email"
              class="form-control"
              type="email"
              required>
          </div>

          <div class="mb-3">
            <label for="register-document" class="form-label">Documento (CPF)</label>
            <input
              id="register-document"
              class="form-control"
              type="text"
              maxlength="14"
              placeholder="Somente números"
              required>
          </div>

          <div class="mb-3">
            <label for="register-phone" class="form-label">Telefone (opcional)</label>
            <input id="register-phone" class="form-control" type="tel" placeholder="(11) 99999-9999">
          </div>

          <div class="mb-3">
            <label for="register-address" class="form-label">Endereço (opcional)</label>
            <input id="register-address" class="form-control" type="text" placeholder="Rua e número">
          </div>

          <div class="mb-3">
            <label for="register-password" class="form-label">Senha</label>
            <input
              id="register-password"
              class="form-control"
              type="password"
              minlength="6"
              required>
          </div>

          <button class="btn btn-store w-100" type="submit">
            Criar cadastro
          </button>
        </form>



        <a href="/login">Já tenho conta</a>
      </div>
    </section>
  `;
}

function pageAccount() {
  document.title = "ONZE STORE | Minha conta";

  const customer = clienteAtual();
  if (!customer?.codigo) {
    return `<section class="container-store store-section"><h1>Minha conta</h1><p>Entre para ver seus dados.</p><a class="btn btn-store" href="/login">Entrar</a></section>`;
  }
  const name = customer.name || "Cliente";
  const email = customer.email || "Não informado";
  const codigo = customer?.codigo || "Não informado";

  return `
    <section class="container-store store-section">
      <h1 class="fw-bold">Minha conta</h1>
      

      <div class="content-card p-4">
        <h2 class="h4 fw-bold">Dados pessoais</h2>
        <p><strong>Nome:</strong> ${escapeHtml(name)}</p>
        <p><strong>E-mail:</strong> ${escapeHtml(email)}</p>
        <p><strong>Código:</strong> ${escapeHtml(codigo)}</p>

        <form id="account-edit" class="mt-3">
          <h3 class="h5">Atualizar cadastro</h3>
          <label class="form-label" for="edit-name">Nome</label>
          <input class="form-control mb-2" id="edit-name" value="${escapeHtml(name)}" required>
          <label class="form-label" for="edit-email">E-mail</label>
          <input class="form-control mb-2" id="edit-email" type="email" value="${escapeHtml(email)}" required>
          <label class="form-label" for="edit-document">Documento</label>
          <input class="form-control mb-2" id="edit-document" placeholder="11 dígitos" value="${escapeHtml(customer.documento || "")}" required>
          <label class="form-label" for="edit-password">Senha para atualização</label>
          <input class="form-control mb-2" id="edit-password" type="password" minlength="6" required>
          <button class="btn btn-store mb-3" type="submit">Salvar alterações</button>
        </form>
        <a class="btn btn-store" href="/pedidos">Ver pedidos</a>
        <button id="logout" class="btn btn-store-outline ms-2">Sair da conta</button>
        <button id="delete-account" class="btn btn-outline-danger ms-2">Excluir cadastro</button>
        <a class="btn btn-store-outline ms-2" href="/busca">Buscar camisetas</a>
      </div>
    </section>
  `;
}

function pageOrders() {
  document.title = "ONZE STORE | Pedidos";

  const cliente = clienteAtual();
  if (!cliente?.codigo) {
    return `<section class="container-store store-section"><h1>Meus pedidos</h1><p>Entre na conta para consultar seus pedidos.</p><a href="/login" class="btn btn-store">Entrar</a></section>`;
  }
  const orders = readStorage("onzeStoreOrders", []).filter((item) => Number(item.customerCode) === Number(cliente.codigo));

  const orderContent = orders.length
    ? orders.map((order) => `
        <article class="order-card">
          <div class="d-flex flex-wrap justify-content-between gap-2">
            <strong>Pedido #${escapeHtml(order.id)}</strong>
            <span>Data: ${escapeHtml(order.date)}</span>
            <strong>${formatPrice(order.total)}</strong>
          </div>

          <p class="small text-secondary mb-2" data-order-status="${Number(order.id)}">Consultando pedido...</p>
          <form class="d-flex flex-wrap gap-2 align-items-center mb-2" data-edit-order="${Number(order.id)}">
            <input class="form-control flex-grow-1" style="min-width:200px" aria-label="Observação do pedido" placeholder="Observação do pedido" maxlength="200" value="${escapeHtml(order.obs || "")}">
            <button type="submit" class="btn btn-sm btn-store-outline">Salvar observação</button>
          </form>
          <button class="btn btn-sm btn-outline-danger" type="button" data-cancel-order="${Number(order.id)}">Excluir pedido</button>
          <ul class="mt-3 mb-0">
            ${(order.items || []).map((item) => `
              <li>
                ${escapeHtml(item.quantity)} × ${escapeHtml(item.name)},
                tamanho ${escapeHtml(item.size)}
              </li>
            `).join("")}
          </ul>
        </article>
      `).join("")
    : `
        <div class="empty-state">
          <h2>Ainda não há pedidos</h2>
          <p>Adicione produtos à cesta para fazer um pedido.</p>
          <a class="btn btn-store" href="/busca">Buscar camisetas</a>
        </div>
      `;

  return `
    <section class="container-store store-section">
      <div class="section-title-row">
        <div>
          <h1>Meus pedidos</h1>
          <p class="section-subtitle">
            Consulte os pedidos realizados nesta loja.
          </p>
        </div>
        <a class="btn btn-store-outline" href="/busca">Continuar comprando</a>
      </div>

      ${orderContent}
    </section>
  `;
}

function renderCart() {
  const container = document.querySelector("#cart-content");
  const totalElement = document.querySelector("#cart-total");
  const checkoutButton = document.querySelector("#checkout-button");

  if (!container || !totalElement || !checkoutButton) {
    return;
  }

  const cart = getCart();

  if (cart.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <h2>Sua cesta está vazia</h2>
        <p>Explore os produtos e adicione uma camiseta.</p>
        <a class="btn btn-store" href="/busca">Buscar camisetas</a>
      </div>
    `;

    totalElement.textContent = formatPrice(0);
    checkoutButton.disabled = true;
    return;
  }

  checkoutButton.disabled = false;

  container.innerHTML = cart.map((item) => `
    <article class="cart-product">
      <img
        src="${item.image}"
        alt="${escapeHtml(item.name)}"
        onerror="this.style.display='none'">

      <div>
        <h2>${escapeHtml(item.name)}</h2>
        <p>${escapeHtml(item.team)} | Tamanho ${escapeHtml(item.size)}</p>
        <strong>${formatPrice(item.price * item.quantity)}</strong>
      </div>

      <div class="quantity-cell">
        <label class="form-label" for="quantity-${item.id}-${item.size}">
          Quantidade
        </label>
        <input
          id="quantity-${item.id}-${item.size}"
          class="form-control"
          type="number"
          min="1"
          value="${Number(item.quantity)}"
          data-quantity-id="${Number(item.id)}"
          data-quantity-size="${escapeHtml(item.size)}">
      </div>

      <div class="remove-cell">
        <button
          class="btn btn-outline-danger"
          type="button"
          data-remove-id="${Number(item.id)}"
          data-remove-size="${escapeHtml(item.size)}">
          Remover
        </button>
      </div>
    </article>
  `).join("");

  const total = cart.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  totalElement.textContent = formatPrice(total);
  updateCartCount();
}

function addProductToCart(productId) {
  const product = products.find((item) => item.id === productId);
  const sizeSelect = document.querySelector("#product-size");

  if (!product || !sizeSelect) {
    return;
  }

  const size = sizeSelect.value;
  const cart = getCart();
  const existing = cart.find(
    (item) => item.id === product.id && item.size === size
  );

  if (existing) {
    existing.quantity += 1;
  } else {
    cart.push({
      ...product,
      quantity: 1,
      size
    });
  }

  saveCart(cart);
  window.location.href = "/cesta";
}

function setupSearch() {
  const form = document.querySelector("#search-form");
  const input = document.querySelector("#search-input");
  const results = document.querySelector("#search-results");
  const count = document.querySelector("#search-count");
  if (!form || !input || !results || !count) return;

  function exibir(lista) {
    count.textContent = `${lista.length} produto(s) encontrado(s)`;
    results.innerHTML = renderProductGrid(lista);
  }

  function filtroLocal() {
    const termo = normalizar(input.value);
    exibir(products.filter((item) =>
      normalizar(`${item.name} ${item.team} ${item.category}`).includes(termo)
    ));
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    const termo = input.value.trim();
    if (!termo) return filtroLocal();
    try {
      const resposta = await LojaAPI.produto.buscar(termo);
      if (!Array.isArray(resposta)) throw new Error("Resposta inesperada da pesquisa.");
      exibir(resposta.map(adaptarProduto));
    } catch (erro) {
      count.textContent = `Erro na pesquisa: ${erro.message}`;
      results.innerHTML = "";
    }
  });
  input.addEventListener("input", filtroLocal);
  filtroLocal();
}

function setupCartEvents() {
  const container = document.querySelector("#cart-content");
  const checkoutButton = document.querySelector("#checkout-button");

  if (!container || !checkoutButton) {
    return;
  }

  container.addEventListener("change", (event) => {
    const input = event.target.closest("[data-quantity-id]");

    if (!input) {
      return;
    }

    const id = Number(input.dataset.quantityId);
    const size = input.dataset.quantitySize;
    const quantity = Math.min(99, Math.max(1, Math.floor(Number(input.value) || 1)));
    const cart = getCart();
    const item = cart.find(
      (entry) => entry.id === id && entry.size === size
    );

    if (item) {
      item.quantity = quantity;
      saveCart(cart);
      renderCart();
    }
  });

  container.addEventListener("click", (event) => {
    const button = event.target.closest("[data-remove-id]");

    if (!button) {
      return;
    }

    const id = Number(button.dataset.removeId);
    const size = button.dataset.removeSize;
    const cart = getCart().filter(
      (item) => item.id !== id || item.size !== size
    );

    saveCart(cart);
    renderCart();
  });

  checkoutButton.addEventListener("click", async () => {
    const cart = getCart();
    if (!cart.length) return;

    const customer = clienteAtual();
    if (!customer?.codigo) {
      alert("Entre na sua conta antes de finalizar o pedido.");
      window.location.href = "/login";
      return;
    }

    checkoutButton.disabled = true;
    checkoutButton.textContent = "Registrando pedido...";
    try {
      const total = Math.round(cart.reduce((soma, item) => soma + item.price * item.quantity, 0) * 100) / 100;
      const hoje = new Date();
      const dataPedido = `${hoje.getFullYear()}-${String(hoje.getMonth() + 1).padStart(2, "0")}-${String(hoje.getDate()).padStart(2, "0")}`;
      // O código do pedido é gerado pelo banco de dados.
      const retorno = await LojaAPI.pedido.cadastrar({
        codigoCliente: Number(customer.codigo),
        dataPedido,
        valorTotal: total,
        entrega: "A combinar",
        obs: "Pedido ONZE STORE"
      });
      const codigoResposta = String(retorno).match(/(\d+)\s*$/);
      if (!codigoResposta) {
        throw new Error("O pedido foi enviado, mas não recebemos o número. Confira no banco antes de tentar novamente.");
      }
      const codigoConfirmacao = Number(codigoResposta[1]);
      if (!codigoConfirmacao) throw new Error("Código de pedido inválido.");

      const orders = readStorage("onzeStoreOrders", []);
      orders.unshift({
        id: codigoConfirmacao,
        date: new Date().toLocaleDateString("pt-BR"),
        total,
        items: cart,
        customerCode: customer.codigo
      });
      saveStorage("onzeStoreOrders", orders);
      saveStorage("onzeStoreLastPedidoCodigo", codigoConfirmacao);
      saveCart([]);
      window.location.href = "/pedidos";
    } catch (erro) {
      alert(`Não foi possível concluir: ${erro.message}`);
      checkoutButton.disabled = false;
      checkoutButton.textContent = "Finalizar pedido";
    }
  });

}

// O backend pode devolver um objeto com propriedades nulas quando o ID não existe.
// Verificamos a chave primária, não apenas a quantidade de campos do JSON.
function pedidoExiste(pedido, codigo) {
  return pedido && Number.isInteger(Number(pedido.codigoPedido))
    && Number(pedido.codigoPedido) > 0
    && Number(pedido.codigoPedido) === Number(codigo);
}

function setupForms() {
  const loginForm = document.querySelector("#login-form");
  if (loginForm) {
    loginForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      const email = document.querySelector("#login-email").value.trim();
      const senha = document.querySelector("#login-password").value;
      try {
        const cliente = await LojaAPI.cliente.login({ email, senha });
        if (!cliente?.codigo) throw new Error("E-mail ou senha inválidos.");
        saveStorage("onzeStoreCustomer", {
          codigo: cliente.codigo, name: cliente.nome,
          email: cliente.email, documento: cliente.documento || ""
        });
        window.location.href = "/conta";
      } catch (erro) {
        mostrarAviso(loginForm, erro.message);
      }
    });
  }

  const registerForm = document.querySelector("#register-form");
  if (registerForm) {
    registerForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      const nome = document.querySelector("#register-name").value.trim();
      const email = document.querySelector("#register-email").value.trim();
      const documento = document.querySelector("#register-document").value.replace(/\D/g, "");
      const senha = document.querySelector("#register-password").value;
      const telefone = document.querySelector("#register-phone").value.trim();
      const logradouro = document.querySelector("#register-address").value.trim();
      if (documento.length !== 11) {
        mostrarAviso(registerForm, "Informe um CPF com 11 dígitos.");
        return;
      }
      try {
        await LojaAPI.cliente.cadastrar({ nome, email, senha, documento, telefone, logradouro, ativo: 1 });
        const cliente = await LojaAPI.cliente.login({ email, senha });
        if (!cliente?.codigo) {
          mostrarAviso(registerForm, "Cadastro enviado. Agora entre usando a tela de login.", false);
          return;
        }
        saveStorage("onzeStoreCustomer", {
          codigo: cliente.codigo, name: cliente.nome,
          email: cliente.email, documento
        });
        window.location.href = "/conta";
      } catch (erro) {
        mostrarAviso(registerForm, erro.message);
      }
    });
  }


}

async function conferirPedidos() {
  const cliente = clienteAtual();
  for (const order of readStorage("onzeStoreOrders", []).filter((item) => Number(item.customerCode) === Number(cliente?.codigo))) {
    const status = document.querySelector(`[data-order-status="${Number(order.id)}"]`);
    if (!status) continue;
    try {
      const pedido = await LojaAPI.pedido.obter(order.id);
      status.textContent = pedidoExiste(pedido, order.id)
        ? "Pedido confirmado."
        : "Pedido não encontrado.";
    } catch (erro) {
      status.textContent = `Não foi possível consultar o pedido: ${erro.message}`;
    }
  }
}

function setupOrders() {
  const buttons = document.querySelectorAll("[data-cancel-order]");
  if (!buttons.length) return;
  conferirPedidos();
  document.querySelectorAll("[data-edit-order]").forEach((form) => {
    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      const codigoPedido = Number(form.dataset.editOrder);
      const obs = form.querySelector("input").value.trim();
      const botao = form.querySelector("button");
      botao.disabled = true;
      try {
        const anterior = await LojaAPI.pedido.obter(codigoPedido);
        if (!pedidoExiste(anterior, codigoPedido)) throw new Error("Pedido não encontrado.");
        await LojaAPI.pedido.atualizar({ ...anterior, codigoPedido, obs });
        const orders = readStorage("onzeStoreOrders", []);
        const salvo = orders.find((pedido) => Number(pedido.id) === codigoPedido);
        if (salvo) salvo.obs = obs;
        saveStorage("onzeStoreOrders", orders);
        mostrarAviso(form, "Observação atualizada.", false);
      } catch (erro) {
        mostrarAviso(form, erro.message);
      } finally {
        botao.disabled = false;
      }
    });
  });
  buttons.forEach((button) => {
    button.addEventListener("click", async () => {
      const codigo = Number(button.dataset.cancelOrder);
      if (!confirm(`Excluir o pedido #${codigo} do banco de dados?`)) return;
      button.disabled = true;
      try {
        await LojaAPI.pedido.excluir(codigo);
        const orders = readStorage("onzeStoreOrders", []);
        saveStorage("onzeStoreOrders", orders.filter((item) => Number(item.id) !== codigo));
        renderPage();
      } catch (erro) {
        alert(`Erro ao excluir pedido: ${erro.message}`);
        button.disabled = false;
      }
    });
  });
}

function setupAccount() {
  const cliente = clienteAtual();
  if (!cliente?.codigo) return;
  const edit = document.querySelector("#account-edit");
  if (edit) {
    LojaAPI.cliente.obter(cliente.codigo).then((dados) => {
      if (!dados || !dados.codigo) return;
      document.querySelector("#edit-name").value = dados.nome || cliente.name;
      document.querySelector("#edit-email").value = dados.email || cliente.email;
      document.querySelector("#edit-document").value = dados.documento || cliente.documento || "";
    }).catch((erro) => mostrarAviso(edit, `Não foi possível consultar cliente: ${erro.message}`));
    edit.addEventListener("submit", async (event) => {
      event.preventDefault();
      const nome = document.querySelector("#edit-name").value.trim();
      const email = document.querySelector("#edit-email").value.trim();
      const documento = document.querySelector("#edit-document").value.replace(/\D/g, "");
      const senha = document.querySelector("#edit-password").value;
      if (documento.length !== 11) return mostrarAviso(edit, "Informe 11 dígitos no documento.");
      try {
        // PUT substitui os dados: preservar telefone, endereço e situação do cadastro.
        const anterior = await LojaAPI.cliente.obter(cliente.codigo);
        if (!anterior?.codigo) throw new Error("Cliente não encontrado.");
        await LojaAPI.cliente.atualizar({ ...anterior, codigo: cliente.codigo, nome, email, documento, senha });
        saveStorage("onzeStoreCustomer", { codigo: cliente.codigo, name: nome, email, documento });
        mostrarAviso(edit, "Cadastro atualizado!", false);
      } catch (erro) {
        mostrarAviso(edit, erro.message);
      }
    });
  }
  document.querySelector("#logout")?.addEventListener("click", () => {
    localStorage.removeItem("onzeStoreCustomer");
    window.location.href = "/login";
  });
  document.querySelector("#delete-account")?.addEventListener("click", async () => {
    if (!confirm("Deseja excluir sua conta?")) return;
    try {
      await LojaAPI.cliente.excluir(cliente.codigo);
      localStorage.removeItem("onzeStoreCustomer");
      window.location.href = "/cadastro";
    } catch (erro) { alert(erro.message); }
  });
}

function renderPage() {
  const path = window.location.pathname.replace(/\/$/, "") || "/";

  const pageRenderers = {
    "/": pageHome,
    "/busca": pageSearch,
    "/detalhe": pageDetail,
    "/cesta": pageCart,
    "/login": pageLogin,
    "/cadastro": pageRegister,
    "/conta": pageAccount,
    "/pedidos": pageOrders
  };

  const renderer = pageRenderers[path] || (() => `
    <section class="container-store store-section">
      <div class="empty-state">
        <h1>Página não encontrada</h1>
        <a class="btn btn-store" href="/">Voltar para a vitrine</a>
      </div>
    </section>
  `);

  app.innerHTML = `
    ${headerTemplate()}
    <main>${renderer()}</main>
    ${footerTemplate()}
  `;

  updateCartCount();
  setupSearch();
  renderCart();
  setupCartEvents();
  setupForms();
  setupOrders();
  setupAccount();

  document.querySelectorAll("[data-add-to-cart]").forEach((button) => {
    button.addEventListener("click", () => {
      addProductToCart(Number(button.dataset.addToCart));
    });
  });
}

carregarProdutos().then(renderPage);
