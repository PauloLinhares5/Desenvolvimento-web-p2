// Endpoints oficiais (documentação de ProdutoController, ClienteController e PedidoController).
// A API Spring Boot deve estar funcionando em http://localhost:8081.
const LojaAPI = (() => {
  const base = window.ONZE_API_URL || `${location.protocol}//${location.hostname}:8081`;

  async function requisicao(caminho, metodo = "GET", dados) {
    const options = { method: metodo };
    if (dados !== undefined) {
      options.headers = { "Content-Type": "application/json" };
      options.body = JSON.stringify(dados);
    }
    let resposta;
    try {
      resposta = await fetch(`${base}${caminho}`, options);
    } catch (erro) {
      throw new Error("API indisponível. Inicie o backend Java na porta 8081.");
    }
    const texto = await resposta.text();
    let conteudo = texto;
    if (texto && (texto.trim().startsWith("{") || texto.trim().startsWith("[") || resposta.headers.get("content-type")?.includes("json"))) {
      try { conteudo = JSON.parse(texto); } catch { /* Resposta textual da API */ }
    }
    if (!resposta.ok) {
      throw new Error(`HTTP ${resposta.status}: ${typeof conteudo === "string" ? conteudo : "Erro na requisição."}`);
    }
    if (typeof conteudo === "string" && /não encontrado|nao encontrado/i.test(conteudo)) {
      throw new Error(conteudo);
    }
    return conteudo;
  }

  return {
    produto: {
      listar: () => requisicao("/api/produtos"),
      vitrine: () => requisicao("/api/produto/vitrine"),
      buscar: (termo) => requisicao(`/api/produto/busca/${encodeURIComponent(termo)}`),
      obter: (codigo) => requisicao(`/api/produto/${encodeURIComponent(codigo)}`),
      cadastrar: (dados) => requisicao("/api/produto", "POST", dados),
      atualizar: (dados) => requisicao("/api/produto", "PUT", dados),
      excluir: (codigo) => requisicao(`/api/produto/${encodeURIComponent(codigo)}`, "DELETE")
    },
    cliente: {
      obter: (codigo) => requisicao(`/api/cliente/${encodeURIComponent(codigo)}`),
      cadastrar: (dados) => requisicao("/api/cliente", "POST", dados),
      atualizar: (dados) => requisicao("/api/cliente", "PUT", dados),
      excluir: (codigo) => requisicao(`/api/cliente/${encodeURIComponent(codigo)}`, "DELETE"),
      login: (dados) => requisicao("/api/cliente/login", "POST", dados),
      resetarSenha: (dados) => requisicao("/api/cliente/resetarSenha", "PATCH", dados),
      alterarSenha: (dados) => requisicao("/api/cliente/alterarSenha", "PATCH", dados)
    },
    pedido: {
      obter: (codigo) => requisicao(`/api/pedido/${encodeURIComponent(codigo)}`),
      cadastrar: (dados) => requisicao("/api/pedido", "POST", dados),
      atualizar: (dados) => requisicao("/api/pedido", "PUT", dados),
      excluir: (codigo) => requisicao(`/api/pedido/${encodeURIComponent(codigo)}`, "DELETE")
    }
  };
})();
